import numpy as np,itertools as it,json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
seed=np.load(D/'reconstructed_seed.npz');ms=seed['masks'].astype(np.int64);cs=seed['real'].astype(np.int64);norm=int(cs@cs);assert norm==8072064
lookup=np.zeros(1<<24,dtype=np.int16);lookup[ms]=cs
mom={int(w):complex(int(r),int(i)) for w,r,i in map(str.split,(D/'moments.tsv').read_text().splitlines())};assert len(mom)==195709 and mom[0]==norm
pairs=list(it.combinations(range(48),2));even=[0]+[(1<<a)|(1<<b) for a,b in pairs];odd=[1<<a for a in range(48)];ei={w:i for i,w in enumerate(even)}
def sign(a,b):
 n=0
 while a:
  l=a&-a;n^=(b&(l-1)).bit_count()&1;a^=l
 return 1-2*n
def dag(w):
 k=w.bit_count();return (-1)**(k*(k-1)//2)
def inner(a,b):return dag(a)*sign(a,b)*mom.get(a^b,0)
def gram(ws):return np.array([[inner(a,b) for b in ws]for a in ws],complex)
E=gram(even);O=gram(odd);assert np.array_equal(E,E.conj().T) and np.array_equal(O,O.conj().T)
print('Gram computed',flush=True)
# Independent direct ordered action on source support (not compiled moment routine).
parity=np.array([i.bit_count()%2 for i in range(256)],dtype=np.int8)
def par(x):return parity[x&255]^parity[(x>>8)&255]^parity[(x>>16)&255]
def action(w):
 m=ms.copy();c=cs.astype(np.complex128)
 for k in reversed([i for i in range(48) if w>>i&1]):
  spin,color=divmod(k,3);b=3*(spin//2)+color;o=spin%2
  c*= (1-2*par(m&((1<<b)-1))) * ((1j*(1-2*((m>>b)&1))) if o else 1)
  m^=1<<b
 return m,c
rng=np.random.default_rng(20261127);sample=[0]+even[1:]+[int(x) for x in rng.choice(np.array(list(mom),dtype=np.int64),size=256,replace=False)]
for w in sample:
 m,c=action(w);assert np.dot(lookup[m].astype(np.int64),c)==mom[w],w
# Check 39 original spin/color generators on the raw integer seed.
WORDS='JIIJ JIJX JXJZ JZJZ JJIZ JJXX JJZX XIII ZIII'.split();flip=[sum(1<<(3-k) for k,c in enumerate(w) if c in 'JX') for w in WORDS];sgn=[sum(1<<(3-k) for k,c in enumerate(w) if c in 'JZ') for w in WORDS]
def g(r,i):return i^flip[r],(-1)**((i&sgn[r]).bit_count())
def idx(i,a):return 3*i+a
def bit(i,a):return 1<<idx(i,a)
def add_term(v,a,b,c):
 w=(1<<a)^(1<<b);v[ei[w]]+=c*(1 if a<=b else -1)
G=[];names=[]
for a,b in it.combinations(range(3),2):
 v=np.zeros(len(even),dtype=np.int64)
 for i in range(16):add_term(v,idx(i,a),idx(i,b),1)
 G.append(v);names.append(f'2G_{a}_{b}')
for r,s in it.combinations(range(9),2):
 v=np.zeros(len(even),dtype=np.int64)
 for a in range(3):
  for i in range(16):
   k,w=g(r,i);j,z=g(s,k);add_term(v,idx(i,a),idx(j,a),w*z)
 G.append(v);names.append(f'8R_{r}_{s}')
G=np.array(G).T;assert np.array_equal(E@G,np.zeros((len(even),39)))
# Direct scatter for all generators; dense work buffer reused.
def direct_linear(terms):
 # exact integer Gaussian coefficients, complex128 sums below 2**53
 out=np.zeros(1<<24,complex)
 for w,z in terms:
  if z:
   m,c=action(w);out[m]+=z*c
 nz=np.flatnonzero(out);return nz,out[nz]
for i in range(39):
 nz,c=direct_linear(zip(even,G[:,i]));assert not len(nz),names[i]
print('39 exact generators',flush=True)
evals=np.linalg.eigvalsh(E/norm);ovals=np.linalg.eigvalsh(O/norm);tol=1e-9;erank=int(sum(evals>tol));orank=int(sum(ovals>tol));print('ranks',erank,orank,'min positive',min(evals[evals>tol]),flush=True)
# exact rank lower bound via modular rank of real Gram (expected real from symmetry)
print('imag max',abs(E.imag).max(),'odd deviation',abs(O-norm*np.eye(48)).max(),flush=True)
# independent direct evaluation of all 16 pointwise source Q on scalar jet.
# derivative of scalar = sqrt(2)*d, value=1, deterministic integer d and x.
x=rng.integers(-2,3,size=(3,9));d=rng.integers(-2,3,size=(3,9));C=np.zeros((48,16),complex)
for a in range(3):
 for i in range(9):
  for al in range(16):
   j,w=g(i,al);C[idx(j,a),al]+=-1j*w*d[a,i]
for i,j in it.combinations(range(9),2):
 for al in range(16):
  k,w=g(i,al);l,z=g(j,k)
  for a in range(3):
   b,c=(a+1)%3,(a+2)%3;C[idx(l,a),al]+=w*z*(x[b,i]*x[c,j]-x[c,i]*x[b,j])
Q=C.conj().T@O@C
vecs=[direct_linear(zip(odd,C[:,i])) for i in range(16)]
Qdirect=np.zeros((16,16),complex)
for i,(m,a) in enumerate(vecs):
 for j,(n,b) in enumerate(vecs):
  _,ii,jj=np.intersect1d(m,n,assume_unique=True,return_indices=True);Qdirect[i,j]=np.vdot(a[ii],b[jj])
assert np.array_equal(Q,Qdirect)
print('Q Gram exact',flush=True)
# Quantify projection of Majorana on normalized degree-two words. Odd Gram = I (test); all mixed parity zero.
assert np.array_equal(O,norm*np.eye(48));leaks=[]
for i in range(48):
 a=1<<i
 for w in even[1:]:
  # <gamma_j psi, gamma_i gamma_w psi>
  vals=np.array([sign(a,w)*inner(b,a^w) for b in odd])/norm
  r=1-float(np.vdot(vals,vals).real);leaks.append((r,i,w))
leaks.sort();print('leaks',leaks[0],leaks[-1],sum(r>1e-9 for r,_,_ in leaks),flush=True)
# Symmetry closure exact at word-degree <=2 for invariant seed: commutator formula on indices.
# confirm for chosen gauge G_01 and representative even word, independently scattered.
def generator_action(m,c,terms):
 out=np.zeros(1<<24,complex)
 for w,z in terms:
  if not z:continue
  mm=m.copy();cc=c.copy()*z
  for k in reversed([i for i in range(48) if w>>i&1]):
   spin,color=divmod(k,3);b=3*(spin//2)+color;o=spin%2
   cc*=(1-2*par(mm&((1<<b)-1)))*((1j*(1-2*((mm>>b)&1))) if o else 1);mm^=1<<b
  out[mm]+=cc
 return out
# [gamma_a gamma_b, gamma_j]=2(delta_bj gamma_a-delta_aj gamma_b); use Clifford multiplication for full commutator.
checks=0
for gi in [0,1,2,3,12,38]:
 terms=[(w,int(z)) for w,z in zip(even,G[:,gi]) if z]
 for w in [odd[0],odd[17],even[1],even[101]]:
  m,c=action(w);direct=generator_action(m,c,terms)
  comm={}
  for a,z in terms:
   ww=a^w;v=z*(sign(a,w)-sign(w,a));comm[ww]=comm.get(ww,0)+v
  comm={w:z for w,z in comm.items() if z};assert all(w.bit_count()<=2 for w in comm)
  n,cc=direct_linear(comm.items());nz=np.flatnonzero(direct);assert np.array_equal(n,nz) and np.array_equal(cc,direct[nz]);checks+=1
print('commutator controls',checks,flush=True)
# CAR failure on a specific degree-two state: gamma_i^2 compression expectation = ||P gamma_i w||^2.
r,i,w=leaks[-1];report={'seed_support':len(ms),'norm2':norm,'degree4_moments':len(mom),'direct_moment_crosschecks':len(sample),'exact_gram_entries':len(E)**2+len(O)**2,'even_words':len(even),'odd_words':len(odd),'rank_even_numerical':erank,'rank_odd_exact':orank,'rank_total_numerical':erank+orank,'even_min_positive_eigenvalue':float(min(evals[evals>tol])),'even_max_abs_null_eigenvalue':float(max(abs(evals[evals<=tol]),default=0)),'even_max_eigenvalue':float(max(evals)),'even_max_imag':float(abs(E.imag).max()),'odd_gram_exact_identity':True,'exact_generator_nulls':39,'generator_coeff_rank_numerical':int(np.linalg.matrix_rank(G)),'source_charge_gram_checks':256,'jet_x':x.tolist(),'jet_scaled_derivative':d.tolist(),'charge_norm2':[float(v.real/norm) for v in Q.diagonal()],'symmetry_commutator_checks':checks,'degree2_majorana_actions':len(leaks),'leaky_actions':sum(r>1e-9 for r,_,_ in leaks),'max_leakage_norm2':r,'max_leakage_gamma':i,'max_leakage_word':[k for k in range(48) if w>>k&1],'mean_leakage_norm2':float(np.mean([r for r,_,_ in leaks])),'min_nonzero_leakage_norm2':min(r for r,_,_ in leaks if r>1e-9),'scope':'Finite normalized Majorana seed moment and source local scalar-jet audit, not physical differential-domain proof.'}
(D/'results.json').write_text(json.dumps(report,indent=2)+'\n');np.save(D/'even_gram_raw.npy',E);print(json.dumps(report,indent=2))
