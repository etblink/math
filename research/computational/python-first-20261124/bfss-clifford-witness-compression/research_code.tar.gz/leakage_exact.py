from pathlib import Path
import itertools as it,json,collections
from fractions import Fraction
D=Path(__file__).resolve().parent
M={int(w):(int(r),int(i)) for w,r,i in map(str.split,(D/'moments.tsv').read_text().splitlines())};N=M[0][0];den=N*N
# For each gamma_i gamma_a gamma_b S, its squared projection onto K1
# equals sum_j |<gamma_j S,gamma_i gamma_a gamma_b S>|^2 / N^2.
# All signs from Clifford reordering disappear in the squared moduli.
hist=collections.Counter()
for i in range(48):
 for a,b in it.combinations(range(48),2):
  w=(1<<i)^(1<<a)^(1<<b);pr=0
  for j in range(48):
   r,s=M[w^(1<<j)];pr+=r*r+s*s
  assert 0<=pr<=den
  hist[Fraction(den-pr,den)]+=1
assert sum(hist.values())==54144
r=json.loads((D/'results.json').read_text());r['exact_degree2_majorana_leakage_histogram']={str(k):v for k,v in sorted(hist.items())};r['exact_leaky_actions']=sum(v for k,v in hist.items() if k);r['exact_full_leakage_actions']=hist[Fraction(1)];r['exact_mean_leakage']=str(sum(k*v for k,v in hist.items())/sum(hist.values()));r['source_seed_sha256']='131e703b19da9a1aea1e137dac45f451bbfc7f64374aff6619a46488410d5ff7';(D/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(r['exact_degree2_majorana_leakage_histogram']);print('fully lost',r['exact_full_leakage_actions'],'mean',r['exact_mean_leakage']);print(r['rank_one_yukawa'])
