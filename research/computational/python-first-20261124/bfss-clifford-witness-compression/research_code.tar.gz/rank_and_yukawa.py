import numpy as np,collections,json,itertools as it,sympy as sp
from pathlib import Path
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from fractions import Fraction
D=Path(__file__).resolve().parent
E=np.load(D/'even_gram_raw.npy').real.astype(np.int64);n,labels=connected_components(csr_matrix(E!=0));blocks=[np.flatnonzero(labels==i) for i in range(n)];N=8072064;p=65521;assert sp.isprime(p)
def rankmod(A):
 A=A.copy()%p;m,n=A.shape;r=0
 for j in range(n):
  i=np.flatnonzero(A[r:,j]);
  if not len(i):continue
  i=int(i[0])+r;A[[r,i]]=A[[i,r]];A[r,j:]=A[r,j:]*pow(int(A[r,j]),-1,p)%p
  A[r+1:,j:]=(A[r+1:,j:]-A[r+1:,j,None]*A[r,None,j:])%p
  r+=1
  if r==m:break
 return r
rank=sum(rankmod(E[np.ix_(ix,ix)]) for ix in blocks)
pairs=list(it.combinations(range(48),2));ei={w:i+1 for i,w in enumerate(pairs)};even=[0]+[(1<<a)|(1<<b) for a,b in pairs];G=[]
words='JIIJ JIJX JXJZ JZJZ JJIZ JJXX JJZX XIII ZIII'.split();f=[sum(1<<(3-k) for k,c in enumerate(w) if c in 'JX') for w in words];s=[sum(1<<(3-k) for k,c in enumerate(w) if c in 'JZ') for w in words]
def g(r,i):return i^f[r],(-1)**((i&s[r]).bit_count())
def term(v,a,b,c):v[ei[tuple(sorted((a,b)))]]+=c*(1 if a<b else -1)
for a,b in it.combinations(range(3),2):
 v=np.zeros(1129,np.int64)
 for i in range(16):term(v,3*i+a,3*i+b,1)
 G.append(v)
for r,s0 in it.combinations(range(9),2):
 v=np.zeros(1129,np.int64)
 for a in range(3):
  for i in range(16):
   k,w=g(r,i);j,z=g(s0,k);term(v,3*i+a,3*j+a,w*z)
 G.append(v)
G=np.array(G).T;gr=rankmod(G);assert gr==39 and np.array_equal(E@G,np.zeros((1129,39),np.int64));assert rank==1129-gr
# Exact polynomial annihilator and modular multiplicity bounds. Distinct rational roots imply diagonalizability.
roots=[Fraction(0),Fraction(29,42),Fraction(19,21),Fraction(1),Fraction(3,2),Fraction(34,21),Fraction(10,3)];mult={str(x):0 for x in roots}
for ix in blocks:
 B=E[np.ix_(ix,ix)];I=np.eye(len(ix),dtype=object);prod=I.copy()
 for x in roots:
  q=x*N;assert q.denominator==1;M=B-int(q)*np.eye(len(ix),dtype=np.int64);prod=prod@M.astype(object);mult[str(x)]+=len(ix)-rankmod(M)
 assert np.all(prod==0)
assert sum(mult.values())==len(E)
print('exact rank, spectrum',rank+48,mult,flush=True)
seed=np.load(D/'reconstructed_seed.npz');ms=seed['masks'].astype(np.int64);cs=seed['real'].astype(np.complex128)
parity=np.array([i.bit_count()%2 for i in range(256)],dtype=np.int8)
def par(x):return parity[x&255]^parity[(x>>8)&255]^parity[(x>>16)&255]
def action(w,m,c):
 m=m.copy();c=c.copy()
 for k in reversed([i for i in range(48) if w>>i&1]):
  spin,color=divmod(k,3);b=3*(spin//2)+color;o=spin%2;c*=(1-2*par(m&((1<<b)-1)))*((1j*(1-2*((m>>b)&1))) if o else 1);m^=1<<b
 return m,c
# Z=iL, rank-one coordinate x[2,2]=1. L=sum_j gamma_(j,0) gamma_(Gamma_2 j,1) times signs.
terms=[]
for j in range(16):
 k,w=g(2,j);a,b=3*j,3*k+1;terms.append(((1<<a)|(1<<b),1j*w*(1 if a<b else -1)))
def Z(m,c):
 out=np.zeros(1<<24,complex)
 for w,z in terms:
  mm,cc=action(w,m,c);out[mm]+=z*cc
 nz=np.flatnonzero(out);return nz,out[nz]
m1,c1=Z(ms,cs);m2,c2=Z(m1,c1);lookup=np.zeros(1<<24,complex);lookup[m2]=c2
b=[]
for w in even:
 m,c=action(w,ms,cs);v=np.vdot(c,lookup[m]);assert v.real==round(v.real) and v.imag==round(v.imag);b.append(v)
# solve exact rational Gram systems on connected blocks, even if singular
proj=sp.Integer(0)
for ix in blocks:
 bb=sp.Matrix([int(b[i].real)+sp.I*int(b[i].imag) for i in ix]);B=sp.Matrix(E[np.ix_(ix,ix)].tolist());sol,params=B.gauss_jordan_solve(bb);sol=sol.subs({z:0 for z in params});assert B*sol==bb;proj+=(bb.conjugate().T*sol)[0]
full=sp.Integer(sum(int(z.real)**2+int(z.imag)**2 for z in c2)); assert all(z.real==int(z.real) and z.imag==int(z.imag) for z in c2); print("norm control",full,proj,np.vdot(c2,c2).real,flush=True); assert int(full)==int(np.vdot(c2,c2).real) and 0<=proj<=full
first=sp.Integer(sum(int(z.real)**2+int(z.imag)**2 for z in c1));print('Z squared: norm',full/N,'projected',proj/N,'lost',(full-proj)/full,flush=True)
r=json.loads((D/'results.json').read_text());r.update({'modular_prime':p,'even_rank_modular':rank,'generator_rank_modular':gr,'exact_total_rank':rank+48,'gram_connected_components':n,'gram_block_sizes':dict(collections.Counter(map(len,blocks))),'exact_normalized_even_gram_spectrum':mult,'exact_spectral_polynomial_annihilator':True,'rank_one_yukawa':{'coordinate':[2,2],'convention':'Z=iL=sqrt(2)Y','Z_seed_support':len(m1),'Z2_seed_support':len(m2),'Z_seed_norm2':str(first/N),'Z2_seed_norm2':str(full/N),'projected_Z2_seed_norm2':str(proj/N),'lost_fraction':str((full-proj)/full),'lost_fraction_float':float((full-proj)/full)}});(D/'results.json').write_text(json.dumps(r,indent=2)+'\n')
