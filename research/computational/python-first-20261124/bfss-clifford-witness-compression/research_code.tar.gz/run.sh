#!/bin/sh
set -eu
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
python reconstruct.py
python - <<'PY'
from pathlib import Path
import hashlib,numpy as np
p=Path('reconstructed_seed.npz');assert hashlib.sha256(p.read_bytes()).hexdigest()=='131e703b19da9a1aea1e137dac45f451bbfc7f64374aff6619a46488410d5ff7'
s=np.load(p);f=open('seed.tsv','w');print(len(s['masks']),file=f);f.writelines(f'{m}\t{c}\n' for m,c in zip(s['masks'],s['real']))
PY
g++ -O3 -std=c++17 moments.cpp -o moments
./moments
python audit.py
python rank_and_yukawa.py
python leakage_exact.py
