import numpy as np,itertools as it
from pathlib import Path
from scipy.sparse import csr_matrix
D=Path(__file__).resolve().parent
alpha='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/-'
vals=[-120,-104,-84,-56,-54,-48,-42,-40,-39,-33,-32,-30,-28,-26,-25,-24,-21,-20,-18,-17,-16,-15,-13,-12,-11,-10,-9,-8,-7,-5,-4,-2,-1,1,2,4,5,6,7,8,9,10,11,12,13,15,16,17,20,21,24,25,26,28,30,32,33,39,40,42,48,54,56,84,104]
s=''.join((D/'seed_packed.txt').read_text().split());h=2166136261
for c in s:h=((h^ord(c))*16777619)&0xffffffff
assert len(s)==3750 and h==0x528ac3d8
I=np.eye(2,dtype=int);X=np.array([[0,1],[1,0]]);Z=np.diag([1,-1]);J=np.array([[0,1],[-1,0]]);Y=np.array([[0,-1j],[1j,0]])
def word(w):
 m=np.ones((1,1),int)
 for c in w:m=np.kron(m,dict(I=I,X=X,Z=Z,J=J)[c])
 return m
S=np.array([word(w) for w in 'JIIJ JIJX JXJZ JZJZ JJIZ JJXX JJZX XIII ZIII'.split()])
def E(a,b):
 m=np.zeros((4,4),int);m[a-1,b-1]=1;m[b-1,a-1]=-1;return m
rho=[E(1,2)+E(3,4),1j*(E(1,2)-E(3,4)),E(1,3)-E(2,4),1j*(E(1,3)+E(2,4)),E(1,4)+E(2,3),1j*(E(1,4)-E(2,3))]
A=[]
for h in [X,Y,-Z]:
 H=np.kron(np.eye(4,dtype=int),h);A.append(np.kron(H.real,I)-np.kron(H.imag,J))
for r in rho:
 B=np.kron(r,J);A.append(np.kron(B.real,Z)+np.kron(B.imag,X))
A=np.array(A,dtype=int);flip=np.ones(9,int);flip[-1]=-1
for i,j in it.product(range(16),repeat=2):
 P=np.zeros((16,16),int);P[i,j]=1
 for k in range(9):P=P+flip[k]*A[k]@P@S[k]
 if np.any(P):P=P//np.gcd.reduce(abs(P.ravel()));break
assert np.array_equal(P.T@P,4*np.eye(16,dtype=int));assert all(np.array_equal(A[i]@P,flip[i]*P@S[i]) for i in range(9))
seed={}
for i in range(0,len(s),5):
 f=[alpha.index(c) for c in s[i:i+4]];v=vals[alpha.index(s[i+4])]
 for t in set(it.permutations(f)):
  m=sum(x<<(6*j) for j,x in enumerate(t));assert m not in seed;seed[m]=v
assert len(seed)==14240 and sum(v*v for v in seed.values())==8072064
# exact exterior map via 2*F3 over Z[i,sqrt(2)]
import sympy as sp
U=sp.Matrix([[1/sp.sqrt(2),0,-1/sp.sqrt(2)],[sp.I/sp.sqrt(2),0,sp.I/sp.sqrt(2)],[0,1,0]])
occ=lambda m,n:[i for i in range(n) if m>>i&1]
def ring(z):
 z=sp.expand(z);a=z.coeff(sp.sqrt(2),0);b=z.coeff(sp.sqrt(2),1);assert sp.simplify(z-a-sp.sqrt(2)*b)==0
 assert all(v.is_Integer for x in [a,b] for v in [sp.re(x),sp.im(x)])
 return complex(a),complex(b)
F3=np.zeros((2,8,8),complex)
for i,j in it.product(range(8),repeat=2):
 if i.bit_count()==j.bit_count():F3[:,i,j]=ring(2*(U.extract(occ(i,3),occ(j,3)).det() if i else 1))
def perm(m,p):
 o=occ(m,len(p));return sum(1<<p[i] for i in o),(-1)**sum(p[i]>p[j] for i,j in it.combinations(o,2))
F6=np.zeros((2,64,64),complex);p6=[3*(i%2)+i//2 for i in range(6)]
for m in range(64):
 q,sg=perm(m,p6)
 for n in range(64):
  a,b=F3[:,n&7,q&7];c,d=F3[:,n>>3,q>>3];F6[:,n,m]=sg*np.array([a*c+2*b*d,a*d+b*c])
def apply(state,M,offset,bits):
 out={};mask=(1<<bits)-1
 mx=max(abs(a.real)+abs(a.imag)+2*(abs(b.real)+abs(b.imag)) for a,b in state.values())
 bound=max(sum(abs(x.real)+abs(x.imag)+2*(abs(y.real)+abs(y.imag)) for x,y in zip(M[0,i],M[1,i])) for i in range(1<<bits));assert mx*bound<2**50
 cols=[[(i,M[0,i,j],M[1,i,j]) for i in range(1<<bits) if M[0,i,j]!=0 or M[1,i,j]!=0] for j in range(1<<bits)]
 for m,(a,b) in state.items():
  j=(m>>offset)&mask;base=m^(j<<offset)
  for i,c,d in cols[j]:
   k=base|(i<<offset);e,f=out.get(k,(0j,0j));out[k]=(e+a*c+2*b*d,f+a*d+b*c)
 return {k:v for k,v in out.items() if v!=(0j,0j)}
state={m:(complex(v),0j) for m,v in seed.items()}
for k in range(4):state=apply(state,F6,6*k,6)
assert all(b==0 and a.real%256==0 and a.imag%256==0 for a,b in state.values())
cart={m:a/256 for m,(a,b) in state.items()};assert len(cart)==19136 and sum(abs(z.real)**2+abs(z.imag)**2 for z in cart.values())==8072064
O=P/2;z=O[:,::2]+1j*O[:,1::2];U8=(z[::2]-1j*z[1::2]).T/2;V8=(z[::2]+1j*z[1::2]).T/2
C=np.zeros((8,256,256),complex)
for j in range(8):
 for m in range(256):
  if m>>j&1:C[j,m^(1<<j),m]=(-1)**((m&((1<<j)-1)).bit_count())
B4=4*(np.einsum('jk,kab->jab',U8,C)+np.einsum('jk,kab->jab',V8,C.conj().transpose(0,2,1)))
assert np.array_equal(B4,np.rint(B4.real)+1j*np.rint(B4.imag))
v4=np.zeros(256,complex)
for m in [85,86,89,90,101,102,105,106,149,150,153,154,165,166,169,170]:v4[m]=(-1)**(int(bool(m&8))+int(bool(m&32)))
assert np.vdot(v4,v4)==16 and all(np.max(abs(b@v4))==0 for b in B4)
T4=np.zeros((256,256),complex);T4[:,0]=16*v4
for m in range(1,256):
 j=(m&-m).bit_length()-1;v=B4[j].conj().T@T4[:,m^(1<<j)];assert np.all(v.real%4==0) and np.all(v.imag%4==0);T4[:,m]=v/4
assert np.array_equal(T4.conj().T@T4,4096*np.eye(256));assert all(np.array_equal(B4[j]@T4,4*T4@C[j]) for j in range(8))
p=[8*(i%3)+i//3 for i in range(24)];inv=np.argsort(p).tolist();state={}
for m,z in cart.items():q,sg=perm(m,p);state[q]=(sg*z,0j)
# Exact sparse matrix on the active 8-bit blocks. Group by the other 16 bits.
from scipy.sparse import coo_matrix
M=T4.conj().T
for a in range(3):
 offset=8*a; mask=255<<offset
 keys=np.fromiter(state,dtype=np.int64); vals=np.fromiter((z for z,b in state.values()),dtype=np.complex128)
 assert all(b==0 for z,b in state.values())
 bases,ix=np.unique(keys & ~mask,return_inverse=True)
 mx=np.max(abs(vals.real)+abs(vals.imag)); bound=np.max(np.sum(abs(M.real)+abs(M.imag),axis=1)); assert mx*bound<2**50
 mat=coo_matrix((vals,((keys>>offset)&255,ix)),shape=(256,len(bases))).tocsr()
 res=(csr_matrix(M)@mat).tocoo();res.eliminate_zeros()
 state={int(bases[c])|(int(r)<<offset):(complex(v),0j) for r,c,v in zip(res.row,res.col,res.data)}
 print('color',a,len(state),flush=True)
denom=64**3;out={}
for m,(z,b) in state.items():
 assert b==0 and z.real%denom==0 and z.imag==0
 q,sg=perm(m,inv);out[q]=int(sg*z.real/denom)
assert len(out)==19136 and sum(v*v for v in out.values())==8072064 and all(m.bit_count()%2==0 for m in out)
ms=np.array(sorted(out),np.uint32);cs=np.array([out[int(m)] for m in ms],np.int16);np.savez_compressed(D/'reconstructed_seed.npz',masks=ms,real=cs,imag=np.zeros_like(cs),raw_norm2=np.int64(8072064));print('reconstructed',len(out),sum(v*v for v in out.values()))
