#include <bits/stdc++.h>
using namespace std; using U=uint64_t;
struct W{U w;uint32_t d,p;int ph;};
W compile(U w){W t{w,0,0,0};for(int k=47;k>=0;k--)if((w>>k)&1){int spin=k/3,color=k%3,bit=3*(spin/2)+color,odd=spin%2;uint32_t p=(1u<<(bit+odd))-1;t.ph=(t.ph+odd+2*(__builtin_parity(p&t.d)))&3;t.p^=p;t.d^=1u<<bit;}return t;}
int main(){ifstream in("seed.tsv");int n;in>>n;vector<uint32_t> m(n);vector<int16_t> c(n), lookup(1<<24);for(int i=0;i<n;i++){int a;in>>m[i]>>a;c[i]=a;lookup[m[i]]=a;}
map<uint32_t,vector<W>> groups;auto add=[&](U w){auto t=compile(w);groups[t.d].push_back(t);};add(0);for(int i=0;i<48;i++)for(int j=i+1;j<48;j++){add((1ull<<i)|(1ull<<j));for(int k=j+1;k<48;k++)for(int l=k+1;l<48;l++)add((1ull<<i)|(1ull<<j)|(1ull<<k)|(1ull<<l));}
ofstream out("moments.tsv");long nwords=0,ninter=0;for(auto &[d,ws]:groups){vector<pair<uint32_t,int>> a;for(int i=0;i<n;i++){int v=lookup[m[i]^d];if(v)a.push_back({m[i],v*c[i]});}ninter+=a.size();for(auto t:ws){long z=0;for(auto [m,v]:a)z+=__builtin_parity(m&t.p)?-v:v;long re=0,im=0;if(t.ph==0)re=z;else if(t.ph==1)im=z;else if(t.ph==2)re=-z;else im=-z;out<<t.w<<'\t'<<re<<'\t'<<im<<'\n';nwords++;}}cerr<<"words "<<nwords<<" groups "<<groups.size()<<" intersect "<<ninter<<"\n";}
