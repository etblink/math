"""Check a fixed BFSS trial using the pinned public companion implementation."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from bfss.blocks import OBSERVABLES
from bfss.hilbert import Basis
from bfss.scalars import ball
from bfss.state import Engine, load
from flint import arb, arb_mat


def verify(input_path: Path, witness_path: Path, cache_path: Path, workers: int):
    witness = json.loads(witness_path.read_text())
    expected_sha256 = witness["input_state_sha256"]
    if hashlib.sha256(input_path.read_bytes()).hexdigest() != expected_sha256:
        raise ValueError("Input state hash differs from the pinned release")

    raw_basis = load(input_path).basis
    labels = witness["labels"]
    coefficients = witness["reduced_basis_coefficients"]
    count = witness["basis_count"]
    if len(labels) != count or len(set(labels)) != count or len(coefficients) != count:
        raise ValueError("The basis labels or coefficient count are invalid")
    if min(labels) < 0 or max(labels) >= len(raw_basis):
        raise ValueError("A basis label is out of range")
    basis = Basis(raw_basis.seeds, [raw_basis[i] for i in labels])
    basis = basis.dilated(1 / basis.reference_width())
    if any(f.profile.b != 1 for f in basis.functions):
        raise ValueError("These reduced coefficients require canonical longitudinal width one")

    dilation = Fraction(witness["lambda_exact"])
    threshold = Fraction(witness["q1_threshold"])
    engine = Engine(cache_path, workers=workers, prec=256, threads=2)
    with engine.arithmetic():
        blocks = engine.blocks(basis)
        x = arb_mat([[ball(coefficient)] for coefficient in coefficients])

        def quad(name):
            return (x.transpose() * (blocks.arb(name) * x))[0, 0]

        norm = quad("M")
        if not norm > 0:
            raise ArithmeticError("The Gram form does not have a strictly positive lower bound")
        energy = {}
        for observable in ("H", "Haux"):
            parts = OBSERVABLES[observable].parts
            energy[observable] = sum(ball(dilation) ** exponent * quad(k) for k, exponent in parts.items())
        numerator = energy["H"] + energy["Haux"]
        if not threshold.denominator * numerator < threshold.numerator * norm:
            raise ArithmeticError("The comparison with the rational threshold did not pass")

        q1 = numerator / norm
        kappa = (36 + 8 * arb(14).sqrt()) / 25
        fidelity = 1 - kappa * q1
        if not fidelity > 0:
            raise ArithmeticError("The lower bound from the companion theorem is inconclusive")
        return {
            "functions": count,
            "dilation": str(dilation),
            "q_H": (energy["H"] / norm).str(34),
            "q_aux": (energy["Haux"] / norm).str(34),
            "q1": q1.str(34),
            "proved_inequality": f"q1 < {threshold}",
            "conditional_fidelity_from_q1": fidelity.str(34),
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_state", type=Path)
    parser.add_argument("witness", type=Path)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--cache", type=Path)
    args = parser.parse_args()
    if args.cache is None:
        with TemporaryDirectory(prefix="bfss-trial-check-") as directory:
            result = verify(args.input_state, args.witness, Path(directory), args.workers)
    else:
        result = verify(args.input_state, args.witness, args.cache, args.workers)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
