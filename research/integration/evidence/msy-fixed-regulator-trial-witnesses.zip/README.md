# Reduced trial witnesses for the fixed-regulator BFSS form

23 November 2026. Read-only research on the public Michel–Scheinpflug–Yin companion implementation at commit `96b19b1fef98486e43bc2527604966c86afd7ca7`.

The witnesses are fixed real coefficient vectors over selected rows of `variational/results/optimized_state.json`. Each JSON file records the zero-based row labels, exact coefficient strings, rational dilation, and SHA-256 of the input state. Widths are first returned to their canonical values with longitudinal width one. The verifier evaluates the corresponding dilated vector in the companion's reduced-form convention. The quotient is invariant under a common coefficient rescaling.

| Witness | Construction | Rational comparison |
| --- | --- | --- |
| 104 terms | Polynomial degree at most 8, canonical widths (2,1) and (3,1), active families S, Phi, H3, dilation 29/20. The coefficients have common denominator 10^13. | q1 < 3/8 |
| 206 terms | Polynomial degree at most 8, the same two canonical widths, eight active families, dilation 7/5. | q1 < 1/3 |
| 1,542 terms | Polynomial degree at most 14, all three earlier canonical widths, dilation 7/5. | q1 < 1/100 |

The numerical search selected finite vectors by optimizing the sum of the ordinary and weighted forms in nested degree cuts and pruning width and seed families. The verifier starts from the fixed coefficients. It uses 256-bit Arb evaluations of the companion's Gram and two energy forms, checks the Gram denominator is strictly positive, and compares the unnormalized numerator and denominator against an exact rational threshold. The `check-*.json` files are outputs of this verification. The screen sampled specified subspaces and dilations, so minimality over all trial constructions remains open.

## Reproduce

Use the pinned [companion release](https://github.com/asmichel/SU2-BFSS/tree/96b19b1fef98486e43bc2527604966c86afd7ca7/variational), with its documented Python environment. From the companion's `variational` directory, run the verifier with the unpacked files.

```sh
uv run python /path/to/unpacked/verify.py results/optimized_state.json /path/to/unpacked/trial-104.json
```

Substitute either other witness filename to reproduce its comparison. The verifier uses a temporary cache by default. Pass `--cache /path/to/cache` to reuse contractions across calls. The release dependency or source setup is described in the companion README.

## Scope of the certificate

In the companion convention, the fixed-regulator quadratic form at epsilon one is the sum of the ordinary and radially weighted forms. The conditional fidelity bound is computed from `1 - kappa * q1`, using the MSY Appendix B bound and the common-domain relation `q_aux <= q1`. The 104-term witness supplies a positive conditional bound, while the 1,542-term witness clears the 97% target. [MSY, Appendix B](https://arxiv.org/html/2611.09837v1#A2)

For the original Lean model, qualification still requires the exact occupation, gauge and charge transports, source form-domain membership, and the singlet and Hardy hypotheses. The 104-term witness's positive Gaussian widths make smooth radial cutoffs a candidate for proving weighted graph membership after transport. This package records numerical evidence in the companion setting.
